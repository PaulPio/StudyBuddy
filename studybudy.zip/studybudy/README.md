# StudyBuddy — Frontend

AI study-companion dashboard: chat, document uploads, generated quizzes, and progress tracking.
Built as BoxLang templates (`.bxm`) with vanilla JS — no build step, so it's fast to hack on during the event.

## Running it

You'll need the [BoxLang MiniServer](https://boxlang.ortusbooks.com/) (or CommandBox) installed.

```bash
# from the studybuddy/ folder
boxlang-miniserver
# then open the URL it prints (usually http://localhost:8080)
```

If your team is running BoxLang a different way (CommandBox `server.json`, Docker, etc.), just point the
webroot at this folder — `index.bxm` is the entry page.

## Project structure

```
studybuddy/
├── Application.bx      # app config — API base URL + mock-mode flag live here
├── index.bxm            # dashboard shell (sidebar nav + 4 views)
├── css/style.css         # design system (see comments at top of file)
├── js/api.js             # ALL backend calls go through here — this is the contract
└── js/app.js             # UI wiring: tabs, chat, uploads, quiz flow, progress
```

## Talking to the backend

The frontend currently runs in **mock mode** — `Application.bx` sets
`this.studyBuddyConfig.useMockData = true`, so `js/api.js` fabricates realistic responses and the whole
dashboard is demoable right now with no backend running.

**When the API is ready:**
1. Flip `useMockData` to `false` in `Application.bx`.
2. Set `apiBaseUrl` if the API isn't mounted at `/api`.
3. Make sure the endpoints below match what `js/api.js` expects (or tell me what's different and I'll
   adjust the frontend instead).

### Endpoint contract

| Endpoint | Method | Request body | Response |
|---|---|---|---|
| `/chat` | POST | `{ message: string, history: [{role, text}] }` | `{ reply: string }` |
| `/documents` | GET | — | `{ documents: [{id, name, status}] }` |
| `/documents` | POST (multipart, field `file`) | file | `{ id, name, status }` |
| `/quizzes/generate` | POST | `{ topic: string, documentId: string\|null }` | `{ questions: [{question, options[], correctIndex}] }` |
| `/quizzes/result` | POST (optional) | `{ topic, score, total }` | `{ ok: boolean }` |
| `/progress` | GET | — | `{ streakDays, quizzesTaken, averageScore, topics: [{name, mastery}] }` |

`status` for documents is `"ready"` or `"processing"` — if parsing takes a while, return `"processing"` and
the frontend will just show that label (polling isn't wired up yet — shout if you need it before the demo
and I'll add it fast).

Full JSDoc for each function (including exact field types) is in `js/api.js` above each function — that's
the source of truth if this table and the code ever disagree.

## Design notes

Theme is "study desk at night": dark slate/navy shell, warm amber lamplight accent, paper-cream content
panels, serif headings paired with a plain sans body. Tokens are documented at the top of `css/style.css`
if you want to reuse the palette elsewhere (e.g. if someone builds a native mobile companion view).

## Known gaps / nice-to-haves if there's time

- No auth yet — assumes single-user session for the demo.
- Quiz generation from a specific document is wired in the UI (`documentId` gets sent) but obviously needs
  the backend to actually use it.
- Progress view re-fetches every time you click the tab; fine for a demo, could cache if the API is slow.
