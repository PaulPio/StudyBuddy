/**
 * StudyBuddy API contract
 * ------------------------
 * This is the single place that talks to the backend. Every function below
 * documents the endpoint it expects. If the backend isn't up yet (or
 * Application.bx has useMockData=true), each function falls back to
 * realistic mock data so the rest of the UI can be built and demoed
 * without waiting on the API team.
 *
 * SHARE THIS FILE'S JSDOC WITH THE BACKEND TEAM — it's the contract.
 */

const StudyBuddyAPI = (() => {

	// Pulled from the <script id="sb-config"> tag BoxLang renders in index.bxm.
	const config = JSON.parse(document.getElementById('sb-config')?.textContent || '{}');
	const BASE = config.apiBaseUrl || '/api';
	const FORCE_MOCK = !!config.useMockData;

	async function callApi(path, options = {}) {
		if (FORCE_MOCK) throw new Error('mock mode enabled');
		const res = await fetch(BASE + path, {
			headers: { 'Content-Type': 'application/json' },
			...options,
		});
		if (!res.ok) throw new Error(`API ${path} returned ${res.status}`);
		return res.json();
	}

	/**
	 * POST /chat
	 * body:  { message: string, history: [{ role: "user"|"agent", text: string }] }
	 * reply: { reply: string }
	 */
	async function sendChatMessage(message, history) {
		try {
			return await callApi('/chat', {
				method: 'POST',
				body: JSON.stringify({ message, history }),
			});
		} catch (e) {
			return mockChatReply(message);
		}
	}

	/**
	 * GET /documents
	 * reply: { documents: [{ id: string, name: string, status: "ready"|"processing" }] }
	 */
	async function listDocuments() {
		try {
			return await callApi('/documents');
		} catch (e) {
			return { documents: mockDocs };
		}
	}

	/**
	 * POST /documents  (multipart/form-data, field name "file")
	 * reply: { id: string, name: string, status: "ready"|"processing" }
	 */
	async function uploadDocument(file) {
		try {
			if (FORCE_MOCK) throw new Error('mock mode enabled');
			const form = new FormData();
			form.append('file', file);
			const res = await fetch(BASE + '/documents', { method: 'POST', body: form });
			if (!res.ok) throw new Error(`upload returned ${res.status}`);
			return res.json();
		} catch (e) {
			const doc = { id: 'doc_' + Date.now(), name: file.name, status: 'ready' };
			mockDocs.push(doc);
			return doc;
		}
	}

	/**
	 * POST /quizzes/generate
	 * body:  { topic: string, documentId: string|null }
	 * reply: { questions: [{ question: string, options: string[], correctIndex: number }] }
	 */
	async function generateQuiz(topic, documentId) {
		try {
			return await callApi('/quizzes/generate', {
				method: 'POST',
				body: JSON.stringify({ topic, documentId }),
			});
		} catch (e) {
			return { questions: mockQuiz(topic) };
		}
	}

	/**
	 * POST /quizzes/result  (optional — lets the backend track progress)
	 * body:  { topic: string, score: number, total: number }
	 * reply: { ok: boolean }
	 */
	async function submitQuizResult(topic, score, total) {
		try {
			return await callApi('/quizzes/result', {
				method: 'POST',
				body: JSON.stringify({ topic, score, total }),
			});
		} catch (e) {
			return { ok: true };
		}
	}

	/**
	 * GET /progress
	 * reply: {
	 *   streakDays: number,
	 *   quizzesTaken: number,
	 *   averageScore: number,      // 0-100
	 *   topics: [{ name: string, mastery: number }]  // mastery 0-100
	 * }
	 */
	async function getProgress() {
		try {
			return await callApi('/progress');
		} catch (e) {
			return mockProgress;
		}
	}

	// ---------------------------------------------------------------
	// Mock data (used only when the real API isn't available yet)
	// ---------------------------------------------------------------

	const mockDocs = [
		{ id: 'doc_1', name: 'Chapter 7 - Cell Biology.pdf', status: 'ready' },
		{ id: 'doc_2', name: 'WWI Lecture Notes.docx', status: 'ready' },
	];

	const mockProgress = {
		streakDays: 4,
		quizzesTaken: 12,
		averageScore: 78,
		topics: [
			{ name: 'Cell Biology', mastery: 82 },
			{ name: 'WWI Causes', mastery: 61 },
			{ name: 'Thermodynamics', mastery: 45 },
		],
	};

	function mockChatReply(message) {
		const canned = [
			"That's a great question — let's break it down step by step.",
			"Here's a simple way to think about it: start with the core definition, then build up to the exceptions.",
			"Want me to quiz you on this once we've covered it?",
			"Good instinct. What part of it is still unclear?",
		];
		return { reply: canned[Math.floor(Math.random() * canned.length)] + ` (echoing: "${message.slice(0, 60)}")` };
	}

	function mockQuiz(topic) {
		const t = topic && topic.trim() ? topic.trim() : 'your notes';
		return [1, 2, 3, 4, 5].map((n) => ({
			question: `Sample question ${n} about ${t}?`,
			options: ['Option A', 'Option B', 'Option C', 'Option D'],
			correctIndex: Math.floor(Math.random() * 4),
		}));
	}

	return {
		sendChatMessage,
		listDocuments,
		uploadDocument,
		generateQuiz,
		submitQuizResult,
		getProgress,
		isMock: () => FORCE_MOCK,
	};
})();
