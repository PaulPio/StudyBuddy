document.addEventListener('DOMContentLoaded', () => {

	// ---------------------------------------------------------------
	// Tab navigation
	// ---------------------------------------------------------------
	const tabs = document.querySelectorAll('.sb-tab');
	const views = document.querySelectorAll('.sb-view');
	const topbarSub = document.getElementById('sb-topbar-sub');
	const subtitles = {
		chat: 'Pick up where you left off, or start something new.',
		uploads: 'The more you upload, the sharper your quizzes get.',
		quizzes: 'A few minutes of testing beats an hour of re-reading.',
		progress: "Here's how your studying is trending.",
	};

	tabs.forEach((tab) => {
		tab.addEventListener('click', () => {
			const view = tab.dataset.view;
			tabs.forEach((t) => { t.classList.remove('is-active'); t.setAttribute('aria-selected', 'false'); });
			tab.classList.add('is-active');
			tab.setAttribute('aria-selected', 'true');
			views.forEach((v) => v.classList.toggle('is-active', v.dataset.view === view));
			topbarSub.textContent = subtitles[view] || '';
			if (view === 'progress') loadProgress();
			if (view === 'uploads') loadDocuments();
		});
	});

	// ---------------------------------------------------------------
	// Chat
	// ---------------------------------------------------------------
	const chatLog = document.getElementById('sb-chat-log');
	const chatForm = document.getElementById('sb-chat-form');
	const chatText = document.getElementById('sb-chat-text');
	let chatHistory = [];

	function appendMessage(role, text) {
		const div = document.createElement('div');
		div.className = 'sb-msg ' + (role === 'user' ? 'sb-msg-user' : 'sb-msg-agent');
		const p = document.createElement('p');
		p.textContent = text;
		div.appendChild(p);
		chatLog.appendChild(div);
		chatLog.scrollTop = chatLog.scrollHeight;
	}

	chatForm.addEventListener('submit', async (e) => {
		e.preventDefault();
		const message = chatText.value.trim();
		if (!message) return;
		appendMessage('user', message);
		chatHistory.push({ role: 'user', text: message });
		chatText.value = '';

		const thinking = document.createElement('div');
		thinking.className = 'sb-msg sb-msg-agent';
		thinking.innerHTML = '<p>...</p>';
		chatLog.appendChild(thinking);
		chatLog.scrollTop = chatLog.scrollHeight;

		const { reply } = await StudyBuddyAPI.sendChatMessage(message, chatHistory);
		thinking.remove();
		appendMessage('agent', reply);
		chatHistory.push({ role: 'agent', text: reply });
	});

	// Enter to send, shift+enter for newline
	chatText.addEventListener('keydown', (e) => {
		if (e.key === 'Enter' && !e.shiftKey) {
			e.preventDefault();
			chatForm.requestSubmit();
		}
	});

	// ---------------------------------------------------------------
	// Uploads
	// ---------------------------------------------------------------
	const dropzone = document.getElementById('sb-dropzone');
	const fileInput = document.getElementById('sb-file-input');
	const docList = document.getElementById('sb-doc-list');
	const quizSourceSelect = document.getElementById('sb-quiz-source');
	let docsLoaded = false;

	function renderDocs(documents) {
		docList.innerHTML = '';
		quizSourceSelect.innerHTML = '<option value="">No document — use topic only</option>';
		documents.forEach((doc) => {
			const li = document.createElement('li');
			const name = document.createElement('span');
			name.textContent = doc.name;
			const status = document.createElement('span');
			status.className = 'sb-doc-status';
			status.textContent = doc.status === 'ready' ? 'Ready' : 'Processing...';
			li.appendChild(name);
			li.appendChild(status);
			docList.appendChild(li);

			const opt = document.createElement('option');
			opt.value = doc.id;
			opt.textContent = doc.name;
			quizSourceSelect.appendChild(opt);
		});
	}

	async function loadDocuments() {
		if (docsLoaded) return;
		docsLoaded = true;
		const { documents } = await StudyBuddyAPI.listDocuments();
		renderDocs(documents);
	}

	async function handleFiles(files) {
		if (!files || !files.length) return;
		for (const file of files) {
			const doc = await StudyBuddyAPI.uploadDocument(file);
			const { documents } = await StudyBuddyAPI.listDocuments();
			renderDocs(documents);
		}
	}

	dropzone.addEventListener('click', () => fileInput.click());
	fileInput.addEventListener('change', (e) => handleFiles(e.target.files));

	['dragenter', 'dragover'].forEach((evt) => {
		dropzone.addEventListener(evt, (e) => {
			e.preventDefault();
			dropzone.classList.add('is-dragover');
		});
	});
	['dragleave', 'drop'].forEach((evt) => {
		dropzone.addEventListener(evt, (e) => {
			e.preventDefault();
			dropzone.classList.remove('is-dragover');
		});
	});
	dropzone.addEventListener('drop', (e) => handleFiles(e.dataTransfer.files));

	// ---------------------------------------------------------------
	// Quizzes
	// ---------------------------------------------------------------
	const quizForm = document.getElementById('sb-quiz-form');
	const quizTopicInput = document.getElementById('sb-quiz-topic');
	const setupPanel = document.getElementById('sb-quiz-setup');
	const activePanel = document.getElementById('sb-quiz-active');
	const resultsPanel = document.getElementById('sb-quiz-results');
	const questionEl = document.getElementById('sb-quiz-question');
	const optionsEl = document.getElementById('sb-quiz-options');
	const nextBtn = document.getElementById('sb-quiz-next');
	const progressLabel = document.getElementById('sb-quiz-progress-label');
	const progressBarFill = document.getElementById('sb-quiz-bar-fill');
	const scoreEl = document.getElementById('sb-quiz-score');
	const retryBtn = document.getElementById('sb-quiz-retry');

	let quizQuestions = [];
	let quizIndex = 0;
	let quizScore = 0;
	let quizTopic = '';
	let answered = false;

	quizForm.addEventListener('submit', async (e) => {
		e.preventDefault();
		quizTopic = quizTopicInput.value.trim();
		const documentId = quizSourceSelect.value || null;
		const { questions } = await StudyBuddyAPI.generateQuiz(quizTopic, documentId);
		quizQuestions = questions;
		quizIndex = 0;
		quizScore = 0;
		setupPanel.classList.add('is-hidden');
		resultsPanel.classList.add('is-hidden');
		activePanel.classList.remove('is-hidden');
		renderQuestion();
	});

	function renderQuestion() {
		answered = false;
		nextBtn.disabled = true;
		const q = quizQuestions[quizIndex];
		questionEl.textContent = q.question;
		progressLabel.textContent = `Question ${quizIndex + 1} of ${quizQuestions.length}`;
		progressBarFill.style.width = `${((quizIndex + 1) / quizQuestions.length) * 100}%`;

		optionsEl.innerHTML = '';
		q.options.forEach((opt, i) => {
			const btn = document.createElement('button');
			btn.className = 'sb-quiz-option';
			btn.type = 'button';
			btn.textContent = opt;
			btn.addEventListener('click', () => selectOption(i, btn));
			optionsEl.appendChild(btn);
		});
	}

	function selectOption(i, btn) {
		if (answered) return;
		answered = true;
		const q = quizQuestions[quizIndex];
		const buttons = optionsEl.querySelectorAll('.sb-quiz-option');
		buttons.forEach((b, idx) => {
			b.disabled = true;
			if (idx === q.correctIndex) b.classList.add('is-correct');
			else if (idx === i) b.classList.add('is-incorrect');
		});
		if (i === q.correctIndex) quizScore++;
		nextBtn.disabled = false;
	}

	nextBtn.addEventListener('click', async () => {
		quizIndex++;
		if (quizIndex < quizQuestions.length) {
			renderQuestion();
		} else {
			await StudyBuddyAPI.submitQuizResult(quizTopic, quizScore, quizQuestions.length);
			activePanel.classList.add('is-hidden');
			resultsPanel.classList.remove('is-hidden');
			scoreEl.textContent = `You scored ${quizScore} out of ${quizQuestions.length}.`;
		}
	});

	retryBtn.addEventListener('click', () => {
		resultsPanel.classList.add('is-hidden');
		setupPanel.classList.remove('is-hidden');
		quizTopicInput.value = '';
	});

	// ---------------------------------------------------------------
	// Progress
	// ---------------------------------------------------------------
	const streakNum = document.getElementById('sb-streak-num');
	const statRow = document.getElementById('sb-stat-row');
	const topicList = document.getElementById('sb-topic-list');
	let progressLoaded = false;

	async function loadProgress() {
		const data = await StudyBuddyAPI.getProgress();
		streakNum.textContent = data.streakDays;

		statRow.innerHTML = '';
		[
			{ num: data.streakDays, label: 'Day streak' },
			{ num: data.quizzesTaken, label: 'Quizzes taken' },
			{ num: data.averageScore + '%', label: 'Average score' },
		].forEach((s) => {
			const div = document.createElement('div');
			div.className = 'sb-stat';
			div.innerHTML = `<span class="sb-stat-num">${s.num}</span><span class="sb-stat-label">${s.label}</span>`;
			statRow.appendChild(div);
		});

		topicList.innerHTML = '';
		data.topics.forEach((t) => {
			const div = document.createElement('div');
			div.className = 'sb-topic';
			div.innerHTML = `
				<span class="sb-topic-name">${t.name}</span>
				<div class="sb-topic-bar"><div class="sb-topic-bar-fill" style="width:${t.mastery}%"></div></div>
				<span class="sb-topic-pct">${t.mastery}%</span>
			`;
			topicList.appendChild(div);
		});
	}

	// Load the streak number on first paint so it's not blank
	loadProgress();
});
